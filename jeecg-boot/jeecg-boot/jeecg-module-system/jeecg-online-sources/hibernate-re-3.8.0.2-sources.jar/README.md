Jeecg-Boot 低代码开发平台
===============

## 开源协议

``` 
Jeecg Boot Online 低代码模块并非开源软件部分，作者保留全部的权利。
此部分不提供源码，仅提供功能，大家可以免费使用，采用LGPL开源协议（不二次改造、不拆分出jeecgboot之外使用，就不产生侵权）。
擅自编译、改造、传播，即属严重侵权行为，与盗窃无异。产生的一切任何后果责任由侵权者自负。

http://www.jeecg.com

``` 

具体开源协议参考：
https://github.com/jeecgboot/jeecg-boot/blob/master/LICENSE